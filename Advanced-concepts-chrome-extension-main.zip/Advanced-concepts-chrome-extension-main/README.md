# Advanced concepts of chrome extension

This is the source code for my [Youtube video](https://youtu.be/tOHpufRbsJc). In this video I explained some advanced concepts of chrome extensions like Background scrips, content scripts and messaging between the two and with popup.
